package com.itheima.googleplay_8.holder;

import android.view.View;

import com.itheima.googleplay_8.base.BaseHolder;
import com.itheima.googleplay_8.bean.CategoryInfoBean;

/**
 * @author  Administrator
 * @time 	2015-7-18 下午4:20:25
 * @des	TODO
 *
 * @version $Rev: 36 $
 * @updateAuthor $Author: admin $
 * @updateDate $Date: 2015-07-18 16:35:29 +0800 (星期六, 18 七月 2015) $
 * @updateDes TODO
 */
public class CategoryHolder extends BaseHolder<CategoryInfoBean> {

	@Override
	public View initHolderView() {
		// TODO
		return null;
	}

	@Override
	public void refreshHolderView(CategoryInfoBean data) {
		// TODO
		
	}

}
