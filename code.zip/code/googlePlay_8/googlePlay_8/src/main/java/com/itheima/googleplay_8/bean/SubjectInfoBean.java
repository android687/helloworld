package com.itheima.googleplay_8.bean;

/**
 * @author  Administrator
 * @time 	2015-7-18 上午11:05:27
 * @des	TODO
 *
 * @version $Rev: 30 $
 * @updateAuthor $Author: admin $
 * @updateDate $Date: 2015-07-18 11:15:47 +0800 (星期六, 18 七月 2015) $
 * @updateDes TODO
 */
public class SubjectInfoBean {
	public String	des;	// 专题描述
	public String	url;	// 专题的url
}
